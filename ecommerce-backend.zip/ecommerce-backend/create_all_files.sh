#!/bin/bash

# This script creates all the remaining backend files

# Create directory structure
mkdir -p src/auth/{dto,guards,strategies,decorators}
mkdir -p src/products/entities
mkdir -p src/products/dto
mkdir -p src/categories/{dto,entities}
mkdir -p src/orders/{dto,entities}
mkdir -p src/cart/{dto,entities}
mkdir -p src/wishlist/{dto,entities}
mkdir -p src/payment/dto
mkdir -p src/email/templates
mkdir -p src/common/{decorators,filters,interceptors,pipes}
mkdir -p src/config

echo "Directory structure created successfully!"
