import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Not } from 'typeorm';
import { Product } from './entities/product.entity';
import { Category } from '../categories/entities/category.entity';
import { Review } from './entities/review.entity';

@Injectable()
export class ProductsService {
  constructor(
    @InjectRepository(Product)
    private productRepository: Repository<Product>,
    @InjectRepository(Category)
    private categoryRepository: Repository<Category>,
    @InjectRepository(Review)
    private reviewRepository: Repository<Review>,
  ) {}

  async create(createProductDto: any): Promise<Product> {
    const category = await this.categoryRepository.findOne({
      where: { id: createProductDto.categoryId },
    });

    if (!category) {
      throw new NotFoundException('Category not found');
    }

    const product = this.productRepository.create({
      ...createProductDto,
      inStock: createProductDto.stockQuantity > 0,
    });

    return this.productRepository.save(product);
  }

  async findAll(filterDto: any) {
    const {
      search,
      category,
      minPrice,
      maxPrice,
      colors,
      sortBy = 'newest',
      page = 1,
      limit = 12,
    } = filterDto;

    const query = this.productRepository
      .createQueryBuilder('product')
      .leftJoinAndSelect('product.category', 'category')
      .leftJoinAndSelect('product.reviews', 'reviews');

    if (search) {
      query.andWhere(
        '(product.name ILIKE :search OR product.description ILIKE :search)',
        { search: `%${search}%` },
      );
    }

    if (category && category !== 'All') {
      query.andWhere('category.name = :category', { category });
    }

    if (minPrice !== undefined) {
      query.andWhere('product.price >= :minPrice', { minPrice });
    }
    if (maxPrice !== undefined) {
      query.andWhere('product.price <= :maxPrice', { maxPrice });
    }

    switch (sortBy) {
      case 'price-low':
        query.orderBy('product.price', 'ASC');
        break;
      case 'price-high':
        query.orderBy('product.price', 'DESC');
        break;
      case 'popularity':
        query.orderBy('product.rating', 'DESC');
        break;
      case 'newest':
      default:
        query.orderBy('product.createdAt', 'DESC');
        break;
    }

    const skip = (page - 1) * limit;
    query.skip(skip).take(limit);

    const [products, total] = await query.getManyAndCount();

    return {
      products,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
    };
  }

  async findOne(id: string): Promise<Product> {
    const product = await this.productRepository.findOne({
      where: { id },
      relations: ['category', 'reviews', 'reviews.user'],
    });

    if (!product) {
      throw new NotFoundException('Product not found');
    }

    return product;
  }

  async update(id: string, updateProductDto: any): Promise<Product> {
    const product = await this.findOne(id);
    Object.assign(product, updateProductDto);

    if (updateProductDto.stockQuantity !== undefined) {
      product.inStock = updateProductDto.stockQuantity > 0;
    }

    return this.productRepository.save(product);
  }

  async remove(id: string): Promise<void> {
    const product = await this.findOne(id);
    await this.productRepository.remove(product);
  }

  async createReview(productId: string, userId: string, createReviewDto: any): Promise<Review> {
    const product = await this.findOne(productId);

    const review = this.reviewRepository.create({
      ...createReviewDto,
      productId,
      userId,
    });

    const savedReview = await this.reviewRepository.save(review);
    await this.updateProductRating(productId);

    return savedReview;
  }

  private async updateProductRating(productId: string): Promise<void> {
    const result = await this.reviewRepository
      .createQueryBuilder('review')
      .select('AVG(review.rating)', 'avgRating')
      .addSelect('COUNT(review.id)', 'count')
      .where('review.productId = :productId', { productId })
      .getRawOne();

    await this.productRepository.update(productId, {
      rating: parseFloat(result.avgRating) || 0,
      reviewCount: parseInt(result.count) || 0,
    });
  }

  async updateStock(productId: string, quantity: number): Promise<void> {
    const product = await this.findOne(productId);
    const newStock = product.stockQuantity - quantity;

    if (newStock < 0) {
      throw new BadRequestException('Insufficient stock');
    }

    await this.productRepository.update(productId, {
      stockQuantity: newStock,
      inStock: newStock > 0,
    });
  }
}
