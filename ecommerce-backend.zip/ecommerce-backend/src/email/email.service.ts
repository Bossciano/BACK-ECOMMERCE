import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as nodemailer from 'nodemailer';

@Injectable()
export class EmailService {
  private transporter;

  constructor(private configService: ConfigService) {
    this.transporter = nodemailer.createTransporter({
      host: configService.get('SMTP_HOST'),
      port: configService.get<number>('SMTP_PORT'),
      secure: configService.get('SMTP_SECURE') === 'true',
      auth: {
        user: configService.get('SMTP_USER'),
        pass: configService.get('SMTP_PASS'),
      },
    });
  }

  async sendWelcomeEmail(email: string, name: string) {
    try {
      await this.transporter.sendMail({
        from: this.configService.get('SMTP_FROM'),
        to: email,
        subject: 'Welcome to E-Commerce!',
        html: `
          <h1>Welcome ${name}!</h1>
          <p>Thank you for registering with us.</p>
        `,
      });
    } catch (error) {
      console.error('Email send error:', error);
    }
  }

  async sendPasswordResetEmail(email: string, name: string, resetUrl: string) {
    try {
      await this.transporter.sendMail({
        from: this.configService.get('SMTP_FROM'),
        to: email,
        subject: 'Password Reset Request',
        html: `
          <h1>Password Reset</h1>
          <p>Hello ${name},</p>
          <p>Click the link below to reset your password:</p>
          <a href="${resetUrl}">Reset Password</a>
          <p>This link will expire in 1 hour.</p>
        `,
      });
    } catch (error) {
      console.error('Email send error:', error);
    }
  }

  async sendOrderConfirmation(email: string, name: string, orderDetails: any) {
    try {
      await this.transporter.sendMail({
        from: this.configService.get('SMTP_FROM'),
        to: email,
        subject: 'Order Confirmation',
        html: `
          <h1>Order Confirmed!</h1>
          <p>Hello ${name},</p>
          <p>Your order has been confirmed.</p>
          <p>Order ID: ${orderDetails.id}</p>
          <p>Total: $${orderDetails.total}</p>
        `,
      });
    } catch (error) {
      console.error('Email send error:', error);
    }
  }
}
