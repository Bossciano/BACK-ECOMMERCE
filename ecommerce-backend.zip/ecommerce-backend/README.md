# E-Commerce Backend API

A production-ready NestJS backend for e-commerce applications with authentication, product management, cart, wishlist, orders, and payment processing.

## Features

- 🔐 **Authentication & Authorization** - JWT-based auth with role-based access control
- 👤 **User Management** - User registration, login, profile management
- 📦 **Product Management** - CRUD operations for products and categories
- 🛒 **Shopping Cart** - Add, update, remove cart items
- ❤️ **Wishlist** - Save favorite products
- 📝 **Orders** - Complete order management system
- 💳 **Payment Integration** - Stripe payment processing
- ⭐ **Reviews & Ratings** - Product reviews and ratings
- 📧 **Email Notifications** - Order confirmations, password reset
- 🔍 **Advanced Filtering** - Search, filter, and sort products
- 📊 **Admin Dashboard** - Order and product management

## Tech Stack

- **Framework**: NestJS
- **Database**: PostgreSQL with TypeORM
- **Authentication**: JWT with Passport
- **Payment**: Stripe
- **Email**: Nodemailer
- **Queue**: Bull (Redis)
- **Documentation**: Swagger/OpenAPI
- **Validation**: class-validator

## Prerequisites

- Node.js (v18 or higher)
- PostgreSQL (v14 or higher)
- Redis (v6 or higher)
- npm or yarn

## Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd ecommerce-backend
```

2. Install dependencies:
```bash
npm install
```

3. Set up environment variables:
```bash
cp .env.example .env
# Edit .env with your configuration
```

4. Create the database:
```bash
createdb ecommerce
```

5. Run migrations:
```bash
npm run migration:run
```

6. Start the development server:
```bash
npm run start:dev
```

The API will be available at `http://localhost:3000`

API Documentation: `http://localhost:3000/api/docs`

## Project Structure

```
ecommerce-backend/
├── src/
│   ├── auth/                 # Authentication module
│   ├── users/                # User management
│   ├── products/             # Product management
│   ├── categories/           # Category management
│   ├── cart/                 # Shopping cart
│   ├── wishlist/             # Wishlist
│   ├── orders/               # Order management
│   ├── payment/              # Payment processing
│   ├── email/                # Email service
│   ├── common/               # Shared utilities
│   ├── config/               # Configuration
│   ├── app.module.ts         # Root module
│   └── main.ts               # Application entry point
├── uploads/                  # File uploads
├── .env.example              # Environment variables template
├── package.json              # Dependencies
└── README.md                 # This file
```

## API Endpoints

### Authentication
- `POST /api/v1/auth/register` - Register new user
- `POST /api/v1/auth/login` - Login user
- `POST /api/v1/auth/logout` - Logout user
- `POST /api/v1/auth/refresh` - Refresh access token
- `POST /api/v1/auth/forgot-password` - Request password reset
- `POST /api/v1/auth/reset-password` - Reset password
- `GET /api/v1/auth/me` - Get current user

### Products
- `GET /api/v1/products` - Get all products (with filters)
- `GET /api/v1/products/:id` - Get product by ID
- `POST /api/v1/products` - Create product (Admin)
- `PATCH /api/v1/products/:id` - Update product (Admin)
- `DELETE /api/v1/products/:id` - Delete product (Admin)
- `POST /api/v1/products/:id/reviews` - Add review

### Categories
- `GET /api/v1/categories` - Get all categories
- `POST /api/v1/categories` - Create category (Admin)

### Cart
- `GET /api/v1/cart` - Get user cart
- `POST /api/v1/cart/items` - Add item to cart
- `PATCH /api/v1/cart/items/:id` - Update cart item
- `DELETE /api/v1/cart/items/:id` - Remove cart item
- `DELETE /api/v1/cart` - Clear cart

### Wishlist
- `GET /api/v1/wishlist` - Get user wishlist
- `POST /api/v1/wishlist/:productId` - Add to wishlist
- `DELETE /api/v1/wishlist/:productId` - Remove from wishlist

### Orders
- `POST /api/v1/orders` - Create order
- `GET /api/v1/orders` - Get user orders
- `GET /api/v1/orders/:id` - Get order by ID
- `PATCH /api/v1/orders/:id/status` - Update order status (Admin)

### Payment
- `POST /api/v1/payment/create-intent` - Create payment intent
- `POST /api/v1/payment/confirm` - Confirm payment

## Environment Variables

See `.env.example` for all required environment variables.

### Database Setup

1. Install PostgreSQL
2. Create a database:
```sql
CREATE DATABASE ecommerce;
```

3. Update `.env` with database credentials

### Redis Setup

Required for Bull queue (email sending, etc.)

```bash
# Install Redis (macOS)
brew install redis

# Start Redis
redis-server
```

### Email Setup

For Gmail:
1. Enable 2-factor authentication
2. Generate an app password
3. Use app password in `SMTP_PASS`

## Running the Application

### Development
```bash
npm run start:dev
```

### Production
```bash
npm run build
npm run start:prod
```

### Testing
```bash
# Unit tests
npm run test

# E2E tests
npm run test:e2e

# Test coverage
npm run test:cov
```

## Database Migrations

```bash
# Generate migration
npm run migration:generate -- -n MigrationName

# Run migrations
npm run migration:run

# Revert migration
npm run migration:revert
```

## Default Admin User

After running migrations, create an admin user:

```sql
INSERT INTO users (email, password, "fullName", role, "isActive")
VALUES (
  'admin@example.com',
  '$2b$10$...',  -- Use bcrypt to hash 'Admin123!'
  'Admin User',
  'admin',
  true
);
```

Or use the seeder script (if implemented).

## Security Best Practices

1. Change all default secrets in `.env`
2. Use strong JWT secrets (256-bit recommended)
3. Enable CORS only for trusted origins
4. Use HTTPS in production
5. Implement rate limiting
6. Keep dependencies updated
7. Use environment-specific configurations

## Deployment

### Using PM2
```bash
npm install -g pm2
npm run build
pm2 start dist/main.js --name ecommerce-api
```

### Using Docker
```bash
docker build -t ecommerce-backend .
docker run -p 3000:3000 ecommerce-backend
```

### Environment-specific builds
```bash
# Production
NODE_ENV=production npm run build
NODE_ENV=production npm run start:prod
```

## Monitoring & Logging

- Application logs are stored in `/logs` directory
- Use PM2 for process monitoring in production
- Integrate with services like Sentry for error tracking

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## License

MIT

## Support

For issues and questions, please open an issue on GitHub.

## Author

Your Name - your.email@example.com
