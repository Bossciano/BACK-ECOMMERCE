# E-Commerce Backend - Complete Setup Guide

## Quick Start (5 Minutes)

### Step 1: Prerequisites
Ensure you have installed:
- **Node.js** 18+ ([Download](https://nodejs.org/))
- **PostgreSQL** 14+ ([Download](https://www.postgresql.org/download/))
- **Redis** 6+ ([Download](https://redis.io/download))
- **Git** ([Download](https://git-scm.com/downloads))

### Step 2: Installation

```bash
# Run the installation script
chmod +x install.sh
./install.sh
```

### Step 3: Database Setup

```bash
# Create the database
createdb ecommerce

# Or using psql
psql -U postgres
CREATE DATABASE ecommerce;
\q
```

### Step 4: Configure Environment

Edit the `.env` file with your settings:

```env
# Database - Update with your PostgreSQL credentials
DB_HOST=localhost
DB_PORT=5432
DB_USERNAME=postgres
DB_PASSWORD=your_password
DB_NAME=ecommerce

# JWT Secrets - IMPORTANT: Change these!
JWT_SECRET=your-super-secret-key-min-32-chars
JWT_REFRESH_SECRET=your-refresh-secret-key-min-32-chars

# Email (Optional for development)
SMTP_HOST=smtp.gmail.com
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
```

### Step 5: Start Redis

```bash
# macOS/Linux
redis-server

# Or as background service
# macOS
brew services start redis

# Linux
sudo systemctl start redis
```

### Step 6: Run the Application

```bash
# Development mode with hot reload
npm run start:dev

# Production mode
npm run build
npm run start:prod
```

### Step 7: Access the API

- **API Base URL**: http://localhost:3000/api/v1
- **API Documentation**: http://localhost:3000/api/docs
- **Health Check**: http://localhost:3000/api/v1/auth/me

## Detailed Configuration

### Database Configuration

#### Option 1: Local PostgreSQL
```env
DB_HOST=localhost
DB_PORT=5432
DB_USERNAME=postgres
DB_PASSWORD=yourpassword
DB_NAME=ecommerce
```

#### Option 2: Cloud Database (e.g., Supabase, AWS RDS)
```env
DB_HOST=your-cloud-db.amazonaws.com
DB_PORT=5432
DB_USERNAME=your_username
DB_PASSWORD=your_password
DB_NAME=ecommerce
```

### Email Configuration

#### Gmail Setup:
1. Enable 2-Factor Authentication
2. Generate App Password: https://myaccount.google.com/apppasswords
3. Use app password in `.env`:

```env
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=yourmail@gmail.com
SMTP_PASS=your-16-char-app-password
```

#### Other Email Providers:

**SendGrid**:
```env
SMTP_HOST=smtp.sendgrid.net
SMTP_PORT=587
SMTP_USER=apikey
SMTP_PASS=your-sendgrid-api-key
```

**Mailgun**:
```env
SMTP_HOST=smtp.mailgun.org
SMTP_PORT=587
SMTP_USER=your-mailgun-username
SMTP_PASS=your-mailgun-password
```

### Stripe Payment Configuration

1. Create account: https://stripe.com
2. Get API keys from: https://dashboard.stripe.com/apikeys
3. Add to `.env`:

```env
STRIPE_SECRET_KEY=sk_test_...
STRIPE_PUBLISHABLE_KEY=pk_test_...
```

### Redis Configuration

```env
# Local Redis
REDIS_HOST=localhost
REDIS_PORT=6379

# Cloud Redis (e.g., Redis Labs)
REDIS_HOST=redis-12345.cloud.redislabs.com
REDIS_PORT=12345
```

## Testing the API

### Using cURL

```bash
# Register a user
curl -X POST http://localhost:3000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "fullName": "John Doe",
    "email": "john@example.com",
    "password": "Password123!"
  }'

# Login
curl -X POST http://localhost:3000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "john@example.com",
    "password": "Password123!"
  }'

# Get products
curl http://localhost:3000/api/v1/products
```

### Using Postman

1. Import the API collection from Swagger:
   - Visit: http://localhost:3000/api/docs
   - Click "Download" → OpenAPI spec
   - Import into Postman

2. Set up environment variables:
   - `base_url`: http://localhost:3000/api/v1
   - `access_token`: (will be set after login)

## Creating an Admin User

Since this is a fresh installation, you need to create an admin user:

### Method 1: Direct Database Insert

```sql
-- Connect to database
psql ecommerce

-- Insert admin user (password is 'Admin123!')
INSERT INTO users (id, email, password, "fullName", role, "isActive", "createdAt", "updatedAt")
VALUES (
  gen_random_uuid(),
  'admin@example.com',
  '$2b$10$YourHashedPasswordHere',
  'Admin User',
  'admin',
  true,
  NOW(),
  NOW()
);
```

### Method 2: Register then Update

```bash
# 1. Register normally
curl -X POST http://localhost:3000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "fullName": "Admin",
    "email": "admin@example.com",
    "password": "Admin123!"
  }'

# 2. Update role in database
psql ecommerce -c "UPDATE users SET role='admin' WHERE email='admin@example.com';"
```

## Project Structure

```
ecommerce-backend/
├── src/
│   ├── auth/              # Authentication & Authorization
│   ├── users/             # User Management
│   ├── products/          # Product Management
│   ├── categories/        # Categories
│   ├── orders/            # Order Processing
│   ├── cart/              # Shopping Cart
│   ├── wishlist/          # Wishlist
│   ├── payment/           # Payment Integration
│   ├── email/             # Email Service
│   ├── app.module.ts      # Root Module
│   └── main.ts            # Entry Point
├── .env                   # Environment Variables
├── package.json           # Dependencies
└── README.md              # Documentation
```

## Common Issues & Solutions

### Issue: "Connection refused" to PostgreSQL

**Solution**:
```bash
# Check if PostgreSQL is running
pg_isready

# Start PostgreSQL
# macOS
brew services start postgresql@14

# Linux
sudo systemctl start postgresql
```

### Issue: "Cannot find module"

**Solution**:
```bash
# Clear node_modules and reinstall
rm -rf node_modules package-lock.json
npm install
```

### Issue: "Redis connection failed"

**Solution**:
```bash
# Check if Redis is running
redis-cli ping
# Should return: PONG

# If not running, start it
redis-server
```

### Issue: Email not sending

**Solution**:
- Verify SMTP credentials
- For Gmail: use App Password, not regular password
- Check firewall settings
- Test SMTP connection:

```bash
telnet smtp.gmail.com 587
```

### Issue: JWT token expired quickly

**Solution**: Update `.env`:
```env
JWT_EXPIRES_IN=1d
JWT_REFRESH_EXPIRES_IN=30d
```

## Development Workflow

### Running in Development Mode

```bash
npm run start:dev
```
- Auto-reloads on file changes
- Detailed error messages
- SQL query logging enabled

### Building for Production

```bash
npm run build
npm run start:prod
```

### Running Tests

```bash
# Unit tests
npm run test

# E2E tests
npm run test:e2e

# Test coverage
npm run test:cov
```

## Deployment

### Option 1: Traditional VPS (DigitalOcean, Linode)

```bash
# Install Node.js, PostgreSQL, Redis on server
# Clone repository
# Set up .env
# Build and run
pm2 start dist/main.js --name ecommerce-api
```

### Option 2: Docker

```bash
docker build -t ecommerce-backend .
docker run -p 3000:3000 ecommerce-backend
```

### Option 3: Cloud Platform (Heroku, Railway, Render)

1. Connect GitHub repository
2. Set environment variables in dashboard
3. Deploy automatically on push

## Security Checklist

- [ ] Changed JWT secrets from defaults
- [ ] Set strong database password
- [ ] Enabled HTTPS in production
- [ ] Set CORS to specific origins only
- [ ] Enabled rate limiting
- [ ] Disabled SQL query logging in production
- [ ] Set `NODE_ENV=production`
- [ ] Implemented helmet for security headers
- [ ] Regular dependency updates

## Monitoring & Logging

### Using PM2 (Production)

```bash
# Install PM2
npm install -g pm2

# Start app
pm2 start dist/main.js --name ecommerce-api

# Monitor
pm2 monit

# Logs
pm2 logs ecommerce-api
```

### Application Logs

Logs are available in:
- Console output (development)
- PM2 logs (production)
- Custom log files (if configured)

## API Endpoints Overview

### Authentication
- `POST /api/v1/auth/register` - Register
- `POST /api/v1/auth/login` - Login
- `GET /api/v1/auth/me` - Get current user

### Products
- `GET /api/v1/products` - List products
- `GET /api/v1/products/:id` - Get product
- `POST /api/v1/products` - Create (Admin)
- `PATCH /api/v1/products/:id` - Update (Admin)
- `DELETE /api/v1/products/:id` - Delete (Admin)

### Orders
- `POST /api/v1/orders` - Create order
- `GET /api/v1/orders` - List orders
- `GET /api/v1/orders/:id` - Get order

For complete API documentation, visit: http://localhost:3000/api/docs

## Support

For issues, questions, or contributions:
- Open an issue on GitHub
- Email: support@yourcompany.com
- Documentation: http://localhost:3000/api/docs

## License

MIT
